select * from t_admin;
select * from t_region;
select * from t_sensor;
select * from t_shade_canopy;

-- 포린키가 2개이상인 테이블이있어서 과정이 이거에 맞춰 들어가지 않으면 안됨 
-- 1. t_region 이게 먼저(지역이름이 먼저 들어온다) 
INSERT INTO t_region (region_name)
VALUES ('화정동');

-- 2. t_admin 그다음은 관리자 (지역이름이 들어와야지 아이디 비번 입력이 가능)
INSERT INTO t_admin(admin_id, admin_pw, region_seq) 
VALUES ('dyrjxm12', 'akdyspwm34', 1);

-- 3. t_shade_canopy 그 뒤에 그늘막 데이터 입력이 가능(데이터베이스 특강때 포린키가 2개 설정되어있기 때문에 위에 2개가 하나라도 없으면 out)
INSERT INTO t_shade_canopy (region_seq, lat, lng, addr, admin_id)
VALUES(1, 36.25626, 38.2525252, '대충주소라는거', 'dyrjxm12');
-- 그리고 여기 lat , lng 는 별도 참조 확인 


-- 4. t_sensor 그늘막이 올라가야지 그뒤에 그늘막에 들어갈 센서값을 저장 가능
INSERT INTO t_sensor(sc_seq, temp, humidity, fine_dust, wind_direction, wind_speed, created_at)
VALUE(1, 1, 1, 1,'남동풍',1, NOW());
-- 이걸로 insert문은 끝인데,  부가적인 문제가 좀 남아있음, 이건 내일 오후 늦게가서 업데이트 할예정 
-- 1. 자동 증가된 값이 포린키로 생성되어서 이 자동생성된 값을 검색해서 맞는 지역이나 업데이트 값을 검색해서 가져와야하는데, 
-- 이건 해결 방법이 2가지 정도 생각됨 
		-- -1. 프로시저로 검색을 만든다 
		-- -2. 2중쿼리문으로 짠다  뭐든지 OK.. 쉬운쪽으로 할거같음
-- 2. t_region 들어올때 무조껀 ~~동으로 지역 등록할 것 이건 기상청 API값 떄문에 그런데, 기상청 API가 
-- 	해당 지역을 검색하면(~~동에 해당하는 lat, lng입력시) 그 해당하는 값을 보여주기 떄문에, ~~동으로 검색한다
-- 3. API는 기상청 사용하여서 센서값을 가져오는데 ,나중에 센서에 insert시킬때는 
-- 라즈베리파이에서 이 지역에 해당하는 지역을 lat, lng가 입력된 딕셔너리 혹은 데이터프레임을 변수에 저장하거나 import 시켜서 사용하는 방안 추천
-- 이는 별도 API_zip에 지역 참조 

-- 그럼 문제는 지역값 주소 받아와서 lat, lng 변환하는 문제가 남았는데? 아 이거 해결함 
-- 별도에 있는 ipynb 참조할 것 google MAP API키 받아와서 변환하는 함수 있음 API는 신임 ㄹㅇㅋㅋ 

-- 내일 와서 이런문제를 천천히 해결하고 각 과정을 맞물리게 좀 짜볼예정입니다 
   